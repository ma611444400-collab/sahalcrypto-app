package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_profiles")
data class UserProfile(
    @PrimaryKey val email: String,
    val name: String,
    val usdtBalance: Double,
    val btcBalance: Double,
    val ethBalance: Double,
    val evcPlusBalance: Double = 2150.0, // Pre-populated values from SCREEN_5
    val eDahabBalance: Double = 2100.0,  // Pre-populated values from SCREEN_5
    val isVerified: Boolean = true
)

@Entity(tableName = "transactions")
data class Transaction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userEmail: String,
    val type: String,          // DEPOSIT, WITHDRAW, BUY, SELL
    val cryptoSymbol: String,  // USDT, BTC, ETH
    val amount: Double,
    val cryptoAmount: Double,
    val paymentMethod: String, // EVC PLUS, EDAHAB, BANK, MARKET_ORDER
    val referenceId: String,   // Reference ID (e.g., 99XJ-11 etc.)
    val status: String,        // SUGAYA_ANSIXIN (Sugaya Ansixin - Pending), LA_ANSIXIYAY (Approved), LA_DIIDAY (Declined)
    val timestamp: Long = System.currentTimeMillis(),
    val screenshotPath: String? = null, // Path to verified screenshot representation
    val details: String = ""
)

@Entity(tableName = "crypto_assets")
data class CryptoAsset(
    @PrimaryKey val symbol: String,
    val id: String,            // coincap id (e.g. bitcoin)
    val name: String,
    val priceUsd: Double,
    val changePercent24h: Double,
    val category: String,      // DHAMMAAN (All), DEFI, LAYER1, STABLECOINS
    val lastUpdated: Long = System.currentTimeMillis()
)
