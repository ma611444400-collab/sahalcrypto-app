package com.example.data.repository

import android.content.Context
import android.util.Log
import com.example.data.api.CoinCapService
import com.example.data.database.AppDatabase
import com.example.data.model.CryptoAsset
import com.example.data.model.Transaction
import com.example.data.model.UserProfile
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.flow
import java.util.UUID

class CryptoRepository(private val context: Context) {
    private val database = AppDatabase.getDatabase(context)
    private val userDao = database.userDao
    private val transactionDao = database.transactionDao
    private val cryptoAssetDao = database.cryptoAssetDao
    private val coinCapService = CoinCapService.create()

    val allAssets: Flow<List<CryptoAsset>> = cryptoAssetDao.getAllAssetsFlow()
    val allTransactions: Flow<List<Transaction>> = transactionDao.getAllTransactionsFlow()

    fun getUserFlow(email: String): Flow<UserProfile?> = userDao.getUserFlow(email)
    fun getTransactionsByUserFlow(email: String): Flow<List<Transaction>> = transactionDao.getTransactionsByUserFlow(email)

    suspend fun getOrCreateProfile(email: String, name: String = "Sahal User"): UserProfile {
        val existing = userDao.getUserByEmail(email)
        if (existing != null) return existing

        // Check if this is the default user email
        val isDefaultUser = email == "user@sahalcrypto.so" || email == "user@sahal-crypto.so" || email == "deeqmaxamed120@gmail.com"
        val profile = if (isDefaultUser) {
            // Match SCREEN_5 configuration: Total Estimated: $12,450.80
            // USDT Tether: 8,200.00
            // EVC Plus Hormuud: 2,150.00
            // eDahab Somtel: 2,100.00
            UserProfile(
                email = email,
                name = if (email == "deeqmaxamed120@gmail.com") "Deeq Maxamed" else name,
                usdtBalance = 8200.0,
                btcBalance = 0.065,  // Approx $4,200
                ethBalance = 0.05,   // Approx $170
                evcPlusBalance = 2150.0,
                eDahabBalance = 2100.0
            )
        } else if (email == "ma611444400@gmail.com") {
            // Admin user details
            UserProfile(
                email = email,
                name = "Maamule (Admin)",
                usdtBalance = 50000.0,
                btcBalance = 1.5,
                ethBalance = 12.0,
                evcPlusBalance = 10000.0,
                eDahabBalance = 10000.0
            )
        } else {
            // Standard new user
            UserProfile(
                email = email,
                name = name,
                usdtBalance = 1000.0,
                btcBalance = 0.0,
                ethBalance = 0.0,
                evcPlusBalance = 500.0,
                eDahabBalance = 500.0
            )
        }

        userDao.insertUser(profile)

        // Seed some initial default transactions for high fidelity (matching screenshots)
        if (isDefaultUser) {
            seedDefaultTransactions(email)
        }

        return profile
    }

    private suspend fun seedDefaultTransactions(email: String) {
        val existingTx = transactionDao.getTransactionsByUserFlow(email).firstOrNull()
        if (existingTx.isNullOrEmpty()) {
            // Pre-seed matching SCREEN_1 & SCREEN_5
            transactionDao.insertTransaction(
                Transaction(
                    userEmail = email,
                    type = "DEPOSIT",
                    cryptoSymbol = "USDT",
                    amount = 500.0,
                    cryptoAmount = 500.0,
                    paymentMethod = "EVC PLUS",
                    referenceId = "99XJ-11",
                    status = "SUGAYA_ANSIXIN", // SUGAYA_ANSIXIN (Pending approval)
                    details = "via Sahal Remit",
                    timestamp = System.currentTimeMillis() - 3600000 // 1 hour ago
                )
            )
            transactionDao.insertTransaction(
                Transaction(
                    userEmail = email,
                    type = "BUY",
                    cryptoSymbol = "BTC",
                    amount = 1200.0,
                    cryptoAmount = 0.018,
                    paymentMethod = "MARKET_ORDER",
                    referenceId = "TX-88219",
                    status = "LA_ANSIXIYAY", // LA_ANSIXIYAY (Approved/Completed)
                    details = "Bitcoin la iibsaday",
                    timestamp = System.currentTimeMillis() - 7200000 // 2 hours ago
                )
            )
            transactionDao.insertTransaction(
                Transaction(
                    userEmail = email,
                    type = "WITHDRAW",
                    cryptoSymbol = "USDT",
                    amount = 250.0,
                    cryptoAmount = 250.0,
                    paymentMethod = "BANK",
                    referenceId = "12PQ-90",
                    status = "LA_DIIDAY", // LA_DIIDAY (Declined)
                    details = "Codsiga Lacag bixin",
                    timestamp = System.currentTimeMillis() - 86400000 // 1 day ago
                )
            )
            // Add a completed deposit so the total balance has correct source history
            transactionDao.insertTransaction(
                Transaction(
                    userEmail = email,
                    type = "DEPOSIT",
                    cryptoSymbol = "USDT",
                    amount = 850.0,
                    cryptoAmount = 850.0,
                    paymentMethod = "eDahab",
                    referenceId = "ED-8822",
                    status = "LA_ANSIXIYAY",
                    details = "Waa dhammaaday",
                    timestamp = System.currentTimeMillis() - 4800000L
                )
            )
        }
    }

    suspend fun seedDefaultAssets() {
        // Seed initial market rates from SCREEN_2
        val defaultAssets = listOf(
            CryptoAsset("BTC", "bitcoin", "Bitcoin", 64241.02, 2.45, "DHAMMAAN"),
            CryptoAsset("ETH", "ethereum", "Ethereum", 3482.11, -1.12, "DHAMMAAN"),
            CryptoAsset("SOL", "solana", "Solana", 145.88, 8.32, "DHAMMAAN"),
            CryptoAsset("XRP", "ripple", "XRP", 0.6214, 0.45, "DHAMMAAN"),
            CryptoAsset("ADA", "cardano", "Cardano", 0.4523, -3.11, "DHAMMAAN"),
            // Popular coins/Gainers from SCREEN_2
            CryptoAsset("PEPE", "pepe", "Pepe", 0.0000124, 24.52, "DEFI"),
            CryptoAsset("FET", "fetch-ai", "Fetch.ai", 1.62, 18.21, "DEFI")
        )
        cryptoAssetDao.insertAssets(defaultAssets)
    }

    suspend fun fetchLiveCryptoFeed() {
        try {
            val response = coinCapService.getAssets()
            val assetsList = response.data.map { dto ->
                val symbol = dto.symbol.uppercase()
                val price = dto.priceUsd.toDoubleOrNull() ?: 1.0
                val change = dto.changePercent24Hr?.toDoubleOrNull() ?: 0.0
                val category = when (symbol) {
                    "USDT", "USDC", "DAI" -> "STABLECOINS"
                    "SOL", "ADA", "AVAX", "DOT" -> "LAYER1"
                    "LDO", "UNI", "AAVE", "MKR" -> "DEFI"
                    else -> "DHAMMAAN"
                }
                CryptoAsset(
                    symbol = symbol,
                    id = dto.id,
                    name = dto.name,
                    priceUsd = price,
                    changePercent24h = change,
                    category = category
                )
            }
            if (assetsList.isNotEmpty()) {
                // Filter down or merge to keep only the ones we trace + major ones
                val supportedSymbols = listOf("BTC", "ETH", "SOL", "XRP", "ADA", "PEPE", "FET", "USDT")
                val filtered = assetsList.filter { it.symbol in supportedSymbols || it.symbol == "BTC" || it.symbol == "ETH" }
                // Also always make sure USDT is exactly 1.0 or extremely close representation
                val finalAssets = filtered.toMutableList()
                if (finalAssets.none { it.symbol == "USDT" }) {
                    finalAssets.add(CryptoAsset("USDT", "tether", "Tether", 1.0, 0.0, "STABLECOINS"))
                }
                if (finalAssets.none { it.symbol == "PEPE" }) {
                    finalAssets.add(CryptoAsset("PEPE", "pepe", "Pepe", 0.0000124, 24.52, "DEFI"))
                }
                if (finalAssets.none { it.symbol == "FET" }) {
                    finalAssets.add(CryptoAsset("FET", "fetch-ai", "Fetch.ai", 1.62, 18.21, "DEFI"))
                }
                cryptoAssetDao.insertAssets(finalAssets)
                Log.d("CryptoRepository", "Crypto prices updated successfully from CoinCap API.")
            }
        } catch (e: Exception) {
            Log.e("CryptoRepository", "Error fetching live CoinCap feed: ${e.localizedMessage}")
            // Fallback: seed/re-seed offline parameters if database is currently empty
            val current = cryptoAssetDao.getAllAssetsFlow().firstOrNull()
            if (current.isNullOrEmpty()) {
                seedDefaultAssets()
            }
            throw e
        }
    }

    // Submit deposit command
    suspend fun submitDeposit(
        email: String,
        amount: Double,
        paymentMethod: String,
        referenceId: String,
        screenshotPath: String?
    ): Boolean {
        val user = userDao.getUserByEmail(email) ?: return false

        // Crucial Financial Isolation: do NOT touch user wallet balance yet!
        // Admin must approve it. Just save transaction as SUGAYA_ANSIXIN (Pending).
        val transaction = Transaction(
            userEmail = email,
            type = "DEPOSIT",
            cryptoSymbol = "USDT",
            amount = amount,
            cryptoAmount = amount, // 1 to 1 for USDT
            paymentMethod = paymentMethod,
            referenceId = referenceId,
            status = "SUGAYA_ANSIXIN",
            screenshotPath = screenshotPath,
            details = "Dhigasho ($paymentMethod)",
            timestamp = System.currentTimeMillis()
        )
        transactionDao.insertTransaction(transaction)
        return true
    }

    // Submit withdrawal command
    suspend fun submitWithdrawal(
        email: String,
        amount: Double,
        paymentMethod: String
    ): Boolean {
        val user = userDao.getUserByEmail(email) ?: return false
        if (user.usdtBalance < amount) return false // Insufficient funds

        // Create withdrawal transaction
        // Financial logic: immediately deduct user USDT, lock it in transaction state "SUGAYA_ANSIXIN".
        // If approved -> stays deducted. If denied -> returned to user USDT.
        val updatedUser = user.copy(
            usdtBalance = user.usdtBalance - amount
        )
        userDao.updateUser(updatedUser)

        val transaction = Transaction(
            userEmail = email,
            type = "WITHDRAW",
            cryptoSymbol = "USDT",
            amount = amount,
            cryptoAmount = amount,
            paymentMethod = paymentMethod,
            referenceId = "W-${UUID.randomUUID().toString().take(6).uppercase()}",
            status = "SUGAYA_ANSIXIN",
            details = "Codsiga Lacag bixin",
            timestamp = System.currentTimeMillis()
        )
        transactionDao.insertTransaction(transaction)
        return true
    }

    // Buy Asset (USDT -> BTC/ETH)
    suspend fun buyAsset(
        email: String,
        symbol: String,
        cryptoAmount: Double,
        usdCost: Double
    ): Boolean {
        val user = userDao.getUserByEmail(email) ?: return false
        if (user.usdtBalance < usdCost) return false // Insufficient USDT

        val updatedUser = when (symbol.uppercase()) {
            "BTC" -> user.copy(
                usdtBalance = user.usdtBalance - usdCost,
                btcBalance = user.btcBalance + cryptoAmount
            )
            "ETH" -> user.copy(
                usdtBalance = user.usdtBalance - usdCost,
                ethBalance = user.ethBalance + cryptoAmount
            )
            else -> return false
        }

        userDao.updateUser(updatedUser)

        transactionDao.insertTransaction(
            Transaction(
                userEmail = email,
                type = "BUY",
                cryptoSymbol = symbol.uppercase(),
                amount = usdCost,
                cryptoAmount = cryptoAmount,
                paymentMethod = "MARKET_ORDER",
                referenceId = "B-${UUID.randomUUID().toString().take(6).uppercase()}",
                status = "LA_ANSIXIYAY", // Internal orders process instantly
                details = "$symbol la iibsaday",
                timestamp = System.currentTimeMillis()
            )
        )
        return true
    }

    // Sell Asset (BTC/ETH -> USDT)
    suspend fun sellAsset(
        email: String,
        symbol: String,
        cryptoAmount: Double,
        usdObtained: Double
    ): Boolean {
        val user = userDao.getUserByEmail(email) ?: return false

        val updatedUser = when (symbol.uppercase()) {
            "BTC" -> {
                if (user.btcBalance < cryptoAmount) return false
                user.copy(
                    btcBalance = user.btcBalance - cryptoAmount,
                    usdtBalance = user.usdtBalance + usdObtained
                )
            }
            "ETH" -> {
                if (user.ethBalance < cryptoAmount) return false
                user.copy(
                    ethBalance = user.ethBalance - cryptoAmount,
                    usdtBalance = user.usdtBalance + usdObtained
                )
            }
            else -> return false
        }

        userDao.updateUser(updatedUser)

        transactionDao.insertTransaction(
            Transaction(
                userEmail = email,
                type = "SELL",
                cryptoSymbol = symbol.uppercase(),
                amount = usdObtained,
                cryptoAmount = cryptoAmount,
                paymentMethod = "MARKET_ORDER",
                referenceId = "S-${UUID.randomUUID().toString().take(6).uppercase()}",
                status = "LA_ANSIXIYAY",
                details = "$symbol la iibiyay",
                timestamp = System.currentTimeMillis()
            )
        )
        return true
    }

    // Admin Process Transaction: Approve deposit or withdrawal securely
    suspend fun adminProcessTransaction(id: Long, approve: Boolean): Boolean {
        val tx = transactionDao.getTransactionById(id) ?: return false
        if (tx.status != "SUGAYA_ANSIXIN") return false // Already finalized

        val client = userDao.getUserByEmail(tx.userEmail) ?: return false

        if (approve) {
            if (tx.type == "DEPOSIT") {
                // Deposit: Add USDT to user's balance
                val updatedClient = client.copy(
                    usdtBalance = client.usdtBalance + tx.amount
                )
                userDao.updateUser(updatedClient)
            }
            // For WITHDRAW, amount was already deducted during submission, so no double deduction is needed.
            transactionDao.updateTransactionStatus(id, "LA_ANSIXIYAY")
        } else {
            if (tx.type == "WITHDRAW") {
                // Withdrawal declined: restore the user's USDT balance!
                val updatedClient = client.copy(
                    usdtBalance = client.usdtBalance + tx.amount
                )
                userDao.updateUser(updatedClient)
            }
            transactionDao.updateTransactionStatus(id, "LA_DIIDAY")
        }
        return true
    }
}
