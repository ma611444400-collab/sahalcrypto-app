package com.example.data.api

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class CoinCapAssetDto(
    @Json(name = "id") val id: String,
    @Json(name = "symbol") val symbol: String,
    @Json(name = "name") val name: String,
    @Json(name = "priceUsd") val priceUsd: String,
    @Json(name = "changePercent24Hr") val changePercent24Hr: String?
)

@JsonClass(generateAdapter = true)
data class CoinCapResponse(
    @Json(name = "data") val data: List<CoinCapAssetDto>
)

interface CoinCapService {
    @GET("v2/assets")
    suspend fun getAssets(): CoinCapResponse

    companion object {
        private const val BASE_URL = "https://api.coincap.io/"

        fun create(): CoinCapService {
            val okHttpClient = OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(15, TimeUnit.SECONDS)
                .build()

            val moshi = com.squareup.moshi.Moshi.Builder()
                .build()

            return Retrofit.Builder()
                .baseUrl(BASE_URL)
                .client(okHttpClient)
                .addConverterFactory(MoshiConverterFactory.create(moshi))
                .build()
                .create(CoinCapService::class.java)
        }
    }
}
