package com.example

import android.app.Application
import android.util.Log

class SahalApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        Log.d("SahalApplication", "Application started...")
        
        // Catch and log any uncaught exceptions to help diagnose stability issues
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            Log.e("SahalApplication", "CRITICAL CRASH DETECTED in thread: ${thread.name}", throwable)
            System.err.println("SahalApplication FATAL CRASH: " + Log.getStackTraceString(throwable))
            
            // Allow the OS to finish the process after logging
            System.exit(1)
        }
    }
}
