package com.example

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.spring
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.CryptoAsset
import com.example.data.model.Transaction
import com.example.data.model.UserProfile
import com.example.ui.CryptoViewModel
import com.example.ui.Language
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {

    companion object {
        var globalCrashMessage by mutableStateOf<String?>(null)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Uncaught Exception Handler (Crash Reporter to capture exact crash reason)
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            val stackTrace = android.util.Log.getStackTraceString(throwable)
            android.util.Log.e("SahalCrypto", "CRITICAL UNCAUGHT EXCEPTION in thread ${thread.name}: ${throwable.message}\n$stackTrace")
            
            // Post to main looper to show on screen
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                try {
                    globalCrashMessage = "CRITICAL ERROR in thread '${thread.name}':\n${throwable.localizedMessage ?: throwable.message}\n\n$stackTrace"
                    Toast.makeText(applicationContext, "Cilad farsamo: ${throwable.message}", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    // fallback
                }
            }
        }

        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val crashMsg = globalCrashMessage
                if (crashMsg != null) {
                    // Safe Crash Reporter Screen so user isn't stuck with a crashing app
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color(0xFF151515))
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(16.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Warning,
                                    contentDescription = "Crash Log",
                                    tint = Color(0xFFFF5252),
                                    modifier = Modifier.size(32.dp)
                                )
                                Text(
                                    text = "Sahal Crypto Crash Reporter",
                                    color = Color(0xFFFF5252),
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            
                            Text(
                                text = "Barnaamijku wuxuu la kulmay cilad weyn. Hoos ka arag tafaasiisha si loo xalliyo / The app encountered a crash. See details:",
                                color = HighContrastWhite,
                                fontSize = 13.sp,
                                lineHeight = 18.sp
                            )
                            
                            androidx.compose.foundation.text.selection.SelectionContainer(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxWidth()
                                    .background(Color.Black)
                                    .border(1.dp, OutlinedGray, RoundedCornerShape(8.dp))
                                    .padding(12.dp)
                            ) {
                                Text(
                                    text = crashMsg,
                                    color = Color(0xFF00FF66),
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.verticalScroll(rememberScrollState())
                                )
                            }
                            
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Button(
                                    onClick = { globalCrashMessage = null },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF5252)),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Eber / Clear & Retry", color = HighContrastWhite)
                                }
                            }
                        }
                    }
                } else {
                    // Immediate UI Render: Force the app to show Dashboard UI immediately upon launch, with NO automatic network calls.
                    MainAppHost()
                }
            }
        }
    }
}

// User-facing layout tab navigations
enum class AppTab {
    DASHBOARD, WALLET, MARKETS, TRADE
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppHost() {
    val viewModel: CryptoViewModel = viewModel()
    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
    val activeEmail by viewModel.currentUserEmail.collectAsStateWithLifecycle()

    var selectedTab by remember { mutableStateOf(AppTab.DASHBOARD) }
    var currentSubScreen by remember { mutableStateOf<String?>(null) } // "SETTINGS" or null

    val isAdmin = activeEmail == "ma611444400@gmail.com"

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = DeepCharcoal,
        contentWindowInsets = WindowInsets.safeDrawing,
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(MintGreen)
                                .border(1.5.dp, HighContrastWhite, CircleShape)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = "Avatar",
                                tint = DeepCharcoal,
                                modifier = Modifier
                                    .size(24.dp)
                                    .align(Alignment.Center)
                            )
                        }
                        Text(
                            text = viewModel.translate("app_title"),
                            fontWeight = FontWeight.Bold,
                            color = MintGreen,
                            fontSize = 20.sp
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { currentSubScreen = "SETTINGS" }) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = HighContrastWhite,
                            modifier = Modifier.testTag("settings_top_btn")
                        )
                    }
                    IconButton(onClick = { /* Simulated Notifications */ }) {
                        Box {
                            Icon(
                                imageVector = Icons.Default.Notifications,
                                contentDescription = "Notifications",
                                tint = HighContrastWhite
                            )
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(MintGreen)
                                    .align(Alignment.TopEnd)
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DeepCharcoal,
                    titleContentColor = HighContrastWhite
                )
            )
        },
        bottomBar = {
            // Adaptive M3 standard bottom bar respects bottom gesture lines automatically
            NavigationBar(
                containerColor = DeepCharcoal,
                tonalElevation = 0.dp,
                modifier = Modifier
                    .drawBehind {
                        // Draw thin sleek top border of Nav bar matching OutlinedGray
                        drawLine(
                            color = OutlinedGray,
                            start = Offset(0f, 0f),
                            end = Offset(size.width, 0f),
                            strokeWidth = 1.dp.toPx()
                        )
                    }
                    .windowInsetsPadding(WindowInsets.navigationBars)
            ) {
                // Tab 1: Dashboard
                NavigationBarItem(
                    selected = selectedTab == AppTab.DASHBOARD && currentSubScreen == null,
                    onClick = {
                        selectedTab = AppTab.DASHBOARD
                        currentSubScreen = null
                    },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Home,
                            contentDescription = "Dashboard"
                        )
                    },
                    label = { Text(viewModel.translate("dashboard"), fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = DeepCharcoal,
                        selectedTextColor = MintGreen,
                        indicatorColor = MintGreen,
                        unselectedIconColor = MutedGray,
                        unselectedTextColor = MutedGray
                    ),
                    modifier = Modifier.testTag("nav_tab_dashboard")
                )

                // Tab 2: Wallet OR Approval (swapped seamlessly based on hardcoded Admin check)
                if (isAdmin) {
                    NavigationBarItem(
                        selected = selectedTab == AppTab.WALLET && currentSubScreen == null,
                        onClick = {
                            selectedTab = AppTab.WALLET
                            currentSubScreen = null
                        },
                        icon = {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Approvals"
                            )
                        },
                        label = { Text(viewModel.translate("admin_tab"), fontSize = 11.sp, color = MintGreen) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = DeepCharcoal,
                            selectedTextColor = MintGreen,
                            indicatorColor = MintGreen,
                            unselectedIconColor = MutedGray,
                            unselectedTextColor = MutedGray
                        ),
                        modifier = Modifier.testTag("nav_tab_admin")
                    )
                } else {
                    NavigationBarItem(
                        selected = selectedTab == AppTab.WALLET && currentSubScreen == null,
                        onClick = {
                            selectedTab = AppTab.WALLET
                            currentSubScreen = null
                        },
                        icon = {
                            Icon(
                                imageVector = Icons.Default.Wallet,
                                contentDescription = "Wallet"
                            )
                        },
                        label = { Text(viewModel.translate("wallet"), fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = DeepCharcoal,
                            selectedTextColor = MintGreen,
                            indicatorColor = MintGreen,
                            unselectedIconColor = MutedGray,
                            unselectedTextColor = MutedGray
                        ),
                        modifier = Modifier.testTag("nav_tab_wallet")
                    )
                }

                // Tab 3: Markets
                NavigationBarItem(
                    selected = selectedTab == AppTab.MARKETS && currentSubScreen == null,
                    onClick = {
                        selectedTab = AppTab.MARKETS
                        currentSubScreen = null
                    },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.TrendingUp,
                            contentDescription = "Markets"
                        )
                    },
                    label = { Text(viewModel.translate("markets"), fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = DeepCharcoal,
                        selectedTextColor = MintGreen,
                        indicatorColor = MintGreen,
                        unselectedIconColor = MutedGray,
                        unselectedTextColor = MutedGray
                    ),
                    modifier = Modifier.testTag("nav_tab_markets")
                )

                // Tab 4: Trade
                NavigationBarItem(
                    selected = selectedTab == AppTab.TRADE && currentSubScreen == null,
                    onClick = {
                        selectedTab = AppTab.TRADE
                        currentSubScreen = null
                    },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.SwapHoriz,
                            contentDescription = "Trade"
                        )
                    },
                    label = { Text(viewModel.translate("trade"), fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = DeepCharcoal,
                        selectedTextColor = MintGreen,
                        indicatorColor = MintGreen,
                        unselectedIconColor = MutedGray,
                        unselectedTextColor = MutedGray
                    ),
                    modifier = Modifier.testTag("nav_tab_trade")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(DeepCharcoal)
        ) {
            // Screen router animation transition
            AnimatedContent(
                targetState = Pair(selectedTab, currentSubScreen),
                transitionSpec = {
                    fadeIn(spring()) togetherWith fadeOut(spring())
                },
                label = "ScreenTransition"
            ) { state ->
                val (tab, subScreen) = state

                if (subScreen == "SETTINGS") {
                    SettingsScreen(viewModel = viewModel, onClose = { currentSubScreen = null })
                } else {
                    when (tab) {
                        AppTab.DASHBOARD -> DashboardScreen(
                            viewModel = viewModel,
                            onQuickDeposit = { selectedTab = AppTab.WALLET },
                            onQuickTrade = { selectedTab = AppTab.TRADE }
                        )
                        AppTab.MARKETS -> MarketsScreen(viewModel = viewModel)
                        AppTab.TRADE -> TradeScreen(viewModel = viewModel)
                        AppTab.WALLET -> {
                            if (isAdmin) {
                                AdminApprovalsScreen(viewModel = viewModel)
                            } else {
                                WalletScreen(viewModel = viewModel)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------
// SCREEN 1: Dashboard
// ----------------------------------------------------
@Composable
fun DashboardScreen(
    viewModel: CryptoViewModel,
    onQuickDeposit: () -> Unit,
    onQuickTrade: () -> Unit
) {
    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
    val transactions by viewModel.userTransactions.collectAsStateWithLifecycle()
    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(vertical = 12.dp)
    ) {
        // Welcoming Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCharcoal),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, OutlinedGray, RoundedCornerShape(24.dp))
                    .testTag("dashboard_balance_card")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = viewModel.translate("total_balance"),
                            style = MaterialTheme.typography.bodyMedium,
                            color = MutedGray,
                            fontWeight = FontWeight.SemiBold
                        )
                        
                        val formattedUSDT = if (userProfile != null) {
                            String.format(Locale.US, "%,.2f", userProfile!!.usdtBalance)
                        } else {
                            "0.00 (Ha rari/Loading)"
                        }
                        Text(
                            text = "$formattedUSDT USDT",
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Black,
                            color = HighContrastWhite,
                            fontFamily = FontFamily.SansSerif
                        )

                        // Equivalent conversion approximation
                        Text(
                            text = "≈ $formattedUSDT USD",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MintGreen,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    // Sophisticated Dark Stat Chip/Badge
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(50.dp))
                            .background(Color(0x1100C087))
                            .border(1.dp, Color(0x3300C087), RoundedCornerShape(50.dp))
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.TrendingUp,
                                contentDescription = "Trending Up",
                                tint = MintGreen,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "+4.25%",
                                color = MintGreen,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Manual Refresh Button Row (Satisfies "Manual Trigger" requirement)
        item {
            val isRefreshing by viewModel.isRefreshing.collectAsStateWithLifecycle()
            val apiError by viewModel.apiError.collectAsStateWithLifecycle()
            
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { viewModel.refreshData() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0x1A00C087),
                        contentColor = MintGreen
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MintGreen.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                        .testTag("dashboard_manual_refresh_btn"),
                    enabled = !isRefreshing
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (isRefreshing) {
                            CircularProgressIndicator(
                                color = MintGreen,
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp
                            )
                            Text(
                                text = "Diiyaar garaynaya / Fetching Rates...",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Manual Refresh",
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "Cusboonaysii Sicirka / Refresh Live Rates",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
                
                apiError?.let { err ->
                    Text(
                        text = err,
                        color = Color(0xFFFF5252),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(horizontal = 4.dp)
                    )
                }
            }
        }

        // Horizontal Tickers Ribbon
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                TickerChip(pair = "BTC/USDT", price = "64,231.20", change = "+2.4%", isPositive = true)
                TickerChip(pair = "ETH/USDT", price = "3,450.00", change = "-1.12%", isPositive = false)
                TickerChip(pair = "SOL/USDT", price = "145.88", change = "+8.32%", isPositive = true)
                TickerChip(pair = "XRP/USDT", price = "0.6214", change = "+0.45%", isPositive = true)
            }
        }

        // Quick Fintech Grids
        item {
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    GridMenuButton(
                        text = viewModel.translate("deposit_button"),
                        subtext = "EVC Plus / eDahab",
                        icon = Icons.Default.AddCircle,
                        isPrimary = true,
                        onClick = onQuickTrade,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("dash_btn_buy")
                    )
                    GridMenuButton(
                        text = viewModel.translate("withdraw_button"),
                        subtext = "Instant cash-out",
                        icon = Icons.Default.Payments,
                        isPrimary = false,
                        onClick = onQuickDeposit,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("dash_btn_withdraw")
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    GridMenuButton(
                        text = viewModel.translate("p2p_button"),
                        subtext = "Local secure trade",
                        icon = Icons.Default.SwapHoriz,
                        isPrimary = false,
                        onClick = {
                            Toast.makeText(context, "Macaamil: Sifada P2P hadda waa dhisgasho tijaabo.", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.weight(1f)
                    )
                    GridMenuButton(
                        text = viewModel.translate("scan_button"),
                        subtext = "Pay via QR Scan",
                        icon = Icons.Default.QrCodeScanner,
                        isPrimary = false,
                        onClick = {
                            Toast.makeText(context, "Skaanerku wuxuu u baahan yahay fasax taleefanka.", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Recent Activity Headers
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = viewModel.translate("recent_activity"),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = HighContrastWhite
                )

                Text(
                    text = viewModel.translate("see_all"),
                    fontSize = 14.sp,
                    color = MintGreen,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.clickable { onQuickDeposit }
                )
            }
        }

        // Recent Transaction lists
        if (transactions.isEmpty()) {
            item {
                EmptyStateCard(viewModel.translate("screenshot_empty"))
            }
        } else {
            items(transactions.take(3)) { transaction ->
                TransactionCardRow(transaction, viewModel)
            }
        }

        // Trending Hot Cryptos
        item {
            Text(
                text = viewModel.translate("assets_top"),
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = HighContrastWhite
            )
        }

        // Default local static indicators
        item {
            TrendingAssetRow(name = "Bitcoin", symbol = "BTC", price = "$64,231", pct = "+3.21%", isUp = true)
        }
        item {
            TrendingAssetRow(name = "Ethereum", symbol = "ETH", price = "$3,450", pct = "+1.15%", isUp = true)
        }
    }
}

@Composable
fun TickerChip(pair: String, price: String, change: String, isPositive: Boolean) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceCharcoal),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.border(1.dp, OutlinedGray, RoundedCornerShape(12.dp))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(pair, color = HighContrastWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(price, color = HighContrastWhite, fontSize = 13.sp)
            Text(
                text = change,
                color = if (isPositive) MintGreen else WarmRed,
                fontWeight = FontWeight.SemiBold,
                fontSize = 12.sp
            )
        }
    }
}

@Composable
fun GridMenuButton(
    text: String,
    subtext: String,
    icon: ImageVector,
    isPrimary: Boolean = false,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceCharcoal),
        shape = RoundedCornerShape(24.dp),
        modifier = modifier
            .height(116.dp)
            .clickable(onClick = onClick)
            .border(
                1.dp,
                OutlinedGray,
                RoundedCornerShape(24.dp)
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.Start
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (isPrimary) MintGreen else Color(0x1A00C087))
                    .then(
                        if (!isPrimary) Modifier.border(1.dp, Color(0x3300C087), RoundedCornerShape(10.dp))
                        else Modifier
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = text,
                    tint = if (isPrimary) DeepCharcoal else MintGreen,
                    modifier = Modifier.size(18.dp)
                )
            }
            
            Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
                Text(
                    text = text,
                    color = HighContrastWhite,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = subtext,
                    color = MutedGray,
                    fontWeight = FontWeight.Medium,
                    fontSize = 10.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun TransactionCardRow(transaction: Transaction, viewModel: CryptoViewModel) {
    val isIncoming = transaction.type == "DEPOSIT"
    val isDeclined = transaction.status == "LA_DIIDAY"
    
    val dateString = remember(transaction.timestamp) {
        SimpleDateFormat("MMM dd, hh:mm a", Locale.getDefault()).format(Date(transaction.timestamp))
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceCharcoal),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, OutlinedGray, RoundedCornerShape(12.dp))
    ) {
        Row(
            modifier = Modifier
                .padding(14.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isIncoming) SoftMint else Color(0x22F6465D))
                ) {
                    Icon(
                        imageVector = if (isIncoming) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                        contentDescription = "Status icon",
                        tint = if (isIncoming) MintGreen else WarmRed,
                        modifier = Modifier.align(Alignment.Center)
                    )
                }

                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = if (transaction.type == "DEPOSIT") "Dhigasho ${transaction.cryptoSymbol}" else if (transaction.type == "WITHDRAW") "Codsiga Lacag bixin" else "${transaction.cryptoSymbol} la iibsaday",
                        color = HighContrastWhite,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "via ${transaction.paymentMethod} • $dateString",
                        color = MutedGray,
                        fontSize = 12.sp
                    )
                }
            }

            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                val sign = if (isIncoming) "+" else "-"
                val amountText = String.format(Locale.US, "%,.2f", transaction.amount)
                Text(
                    text = "$sign$amountText",
                    color = if (isDeclined) MutedGray else HighContrastWhite,
                    fontWeight = FontWeight.Black,
                    fontSize = 15.sp
                )

                // Capsule Status Label Matching EXACT pixel models from images
                val (statusText, statusBg, statusColor) = when (transaction.status) {
                    "SUGAYA_ANSIXIN" -> Triple(viewModel.translate("admin_required"), Color(0xFF3F3514), LightYellow)
                    "LA_ANSIXIYAY" -> Triple(viewModel.translate("approved"), Color(0xFF0F3D2A), MintGreen)
                    else -> Triple(viewModel.translate("declined"), Color(0xFF3F1920), WarmRed)
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(statusBg)
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = statusText,
                        fontSize = 10.sp,
                        color = statusColor,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }
    }
}

@Composable
fun TrendingAssetRow(name: String, symbol: String, price: String, pct: String, isUp: Boolean) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceCharcoal.copy(alpha = 0.5f)),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, OutlinedGray.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
    ) {
        Row(
            modifier = Modifier
                .padding(14.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(OutlinedGray)
                ) {
                    Text(
                        text = symbol.take(2),
                        color = MintGreen,
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp,
                        modifier = Modifier.align(Alignment.Center)
                    )
                }
                Column {
                    Text(name, color = HighContrastWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(symbol, color = MutedGray, fontSize = 12.sp)
                }
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(price, color = HighContrastWhite, fontWeight = FontWeight.Black, fontSize = 14.sp)
                Text(pct, color = if (isUp) MintGreen else WarmRed, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

// ----------------------------------------------------
// SCREEN 2: Markets (Suuqa)
// ----------------------------------------------------
@Composable
fun MarketsScreen(viewModel: CryptoViewModel) {
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val filteredAssets by viewModel.filteredCryptoAssets.collectAsStateWithLifecycle()
    val apiError by viewModel.apiError.collectAsStateWithLifecycle()
    val isRefreshing by viewModel.isRefreshing.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 20.dp, top = 8.dp)
    ) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = viewModel.translate("market_header"),
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = HighContrastWhite,
                    modifier = Modifier.testTag("markets_header_title")
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(MintGreen)
                    )
                    Text(
                        text = viewModel.translate("market_update_text"),
                        fontSize = 12.sp,
                        color = MutedGray
                    )
                }
            }
        }

        apiError?.let { errorMsg ->
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0x22FF5252)),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Color(0x44FF5252), RoundedCornerShape(16.dp))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = "Error icon",
                                tint = Color(0xFFFF5252),
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = "Cilad Khadka / Connection Issue",
                                color = Color(0xFFFF5252),
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                        Text(
                            text = errorMsg,
                            color = HighContrastWhite,
                            fontSize = 12.sp,
                            lineHeight = 16.sp
                        )
                        Button(
                            onClick = { viewModel.refreshData() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFFF5252),
                                contentColor = HighContrastWhite
                            ),
                            shape = RoundedCornerShape(8.dp),
                            enabled = !isRefreshing,
                            modifier = Modifier.align(Alignment.End)
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (isRefreshing) {
                                    CircularProgressIndicator(
                                        color = HighContrastWhite,
                                        modifier = Modifier.size(16.dp),
                                        strokeWidth = 2.dp
                                    )
                                } else {
                                    Icon(Icons.Default.Refresh, contentDescription = "Retry", modifier = Modifier.size(16.dp))
                                    Text(text = "Diiyaar garee / Retry", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Live Search Input Layout
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.setSearchQuery(it) },
                placeholder = { Text(viewModel.translate("search_asset"), color = MutedGray) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = MutedGray) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = HighContrastWhite,
                    unfocusedTextColor = HighContrastWhite,
                    focusedContainerColor = SurfaceCharcoal,
                    unfocusedContainerColor = SurfaceCharcoal,
                    focusedBorderColor = MintGreen,
                    unfocusedBorderColor = OutlinedGray
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("market_search_input")
            )
        }

        // Horizontal Category selectors
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("DHAMMAAN", "DEFI", "LAYER1", "STABLECOINS").forEach { category ->
                    val isSelected = selectedCategory == category
                    val displayLabel = when (category) {
                        "DHAMMAAN" -> viewModel.translate("all")
                        "DEFI" -> viewModel.translate("defi")
                        "LAYER1" -> viewModel.translate("layer1")
                        else -> viewModel.translate("stablecoins")
                    }
                    Button(
                        onClick = { viewModel.setSelectedCategory(category) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isSelected) MintGreen else SurfaceCharcoal,
                            contentColor = if (isSelected) DeepCharcoal else HighContrastWhite
                        ),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("category_filter_$category")
                    ) {
                        Text(displayLabel, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        }

        // Table Header Label Titles
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "Hantida", color = MutedGray, fontSize = 12.sp, modifier = Modifier.weight(1.5f))
                Text(text = "Sicirka", color = MutedGray, fontSize = 12.sp, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
                Text(text = "Isbeddelka 24h", color = MutedGray, fontSize = 12.sp, modifier = Modifier.weight(1f), textAlign = TextAlign.End)
            }
        }

        if (filteredAssets.isEmpty()) {
            item {
                EmptyStateCard("Macaamil: Wax xog ah lagama helin halkan.")
            }
        } else {
            items(filteredAssets) { asset ->
                MarketRateRow(asset)
            }
        }

        item {
            Divider(color = OutlinedGray, modifier = Modifier.padding(vertical = 4.dp))
        }

        // Top Gainers High contrast blocks
        item {
            Text(
                text = viewModel.translate("top_gainers"),
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = HighContrastWhite
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                GainerCard("Pepe (PEPE)", "+24.52%", MintGreen, modifier = Modifier.weight(1f))
                GainerCard("Fetch.ai (FET)", "+18.21%", MintGreen, modifier = Modifier.weight(1f))
            }
        }

        // Marketing Campaign Card Block
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MintGreen),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Campaign icon",
                        tint = DeepCharcoal,
                        modifier = Modifier.size(28.dp)
                    )
                    Text(
                        text = "Sahal Pro",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        color = DeepCharcoal
                    )
                    Text(
                        text = "Fur jaartiga horumarsan & ganacsiga khidmad la'aanta ah ee dhanka suuqyada caalamiga ah.",
                        fontSize = 13.sp,
                        color = DeepCharcoal,
                        fontWeight = FontWeight.Medium
                    )

                    Button(
                        onClick = { /* simulated Upgrade */ },
                        colors = ButtonDefaults.buttonColors(containerColor = DeepCharcoal),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Hadda cusboonaysii", color = MintGreen, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun MarketRateRow(asset: CryptoAsset) {
    val isPositive = asset.changePercent24h >= 0

    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceCharcoal.copy(alpha = 0.5f)),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, OutlinedGray.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
    ) {
        Row(
            modifier = Modifier
                .padding(14.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Ticker & Information
            Row(
                modifier = Modifier.weight(1.5f),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(OutlinedGray)
                ) {
                    Text(
                        text = asset.symbol.take(2),
                        color = MintGreen,
                        fontWeight = FontWeight.Black,
                        fontSize = 13.sp,
                        modifier = Modifier.align(Alignment.Center)
                    )
                }
                Column {
                    Text(
                        text = asset.name,
                        color = HighContrastWhite,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(text = asset.symbol, color = MutedGray, fontSize = 12.sp)
                }
            }

            // Price Usd
            val priceText = if (asset.priceUsd < 1.0) {
                String.format(Locale.US, "$%,.4f", asset.priceUsd)
            } else {
                String.format(Locale.US, "$%,.2f", asset.priceUsd)
            }
            Text(
                text = priceText,
                color = HighContrastWhite,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                modifier = Modifier.weight(1f),
                textAlign = TextAlign.End
            )

            // Percent Change capsule block representation
            Box(
                modifier = Modifier
                    .weight(1f)
                    .wrapContentWidth(Alignment.End)
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (isPositive) Color(0xFF0F3D2A) else Color(0xFF3F1920))
                    .padding(horizontal = 8.dp, vertical = 6.dp)
            ) {
                val percentageSign = if (isPositive) "+" else ""
                Text(
                    text = String.format(Locale.US, "%s%.2f%%", percentageSign, asset.changePercent24h),
                    color = if (isPositive) MintGreen else WarmRed,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
            }
        }
    }
}

@Composable
fun GainerCard(coin: String, percent: String, tint: Color, modifier: Modifier = Modifier) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceCharcoal.copy(alpha = 0.5f)),
        shape = RoundedCornerShape(16.dp),
        modifier = modifier.border(1.dp, OutlinedGray.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(text = coin, color = HighContrastWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(text = percent, color = tint, fontWeight = FontWeight.Black, fontSize = 16.sp)
        }
    }
}

// ----------------------------------------------------
// SCREEN 3: Trade (Ganacsiga)
// ----------------------------------------------------
@Composable
fun TradeScreen(viewModel: CryptoViewModel) {
    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var selectedCoin by remember { mutableStateOf("BTC") } // BTC / ETH
    var isBuyFlow by remember { mutableStateOf(true) } // Buy vs Sell
    var enterAmountString by remember { mutableStateOf("100") }
    var selectedWalletOption by remember { mutableStateOf("EVC_PLUS") } // EVC_PLUS vs EDAHAB

    val coinSelectionList = listOf("BTC", "ETH")

    // Estimated asset valuation rates retrieved dynamically
    val testRateBtc = 64241.02
    val testRateEth = 3482.11
    val liveRate = if (selectedCoin == "BTC") testRateBtc else testRateEth

    val parsedAmount = enterAmountString.toDoubleOrNull() ?: 0.0
    val clientBalance = userProfile?.usdtBalance ?: 0.0

    val calculatedTargetCrypto = if (isBuyFlow) parsedAmount / liveRate else parsedAmount * liveRate
    val transactionFee = parsedAmount * 0.02
    val grandTotalCost = if (isBuyFlow) parsedAmount + transactionFee else parsedAmount - transactionFee

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(vertical = 12.dp)
    ) {
        // Toggle Switch Buy/Sell tab styles
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SurfaceCharcoal, RoundedCornerShape(12.dp))
                    .padding(4.dp)
            ) {
                Button(
                    onClick = { isBuyFlow = true },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isBuyFlow) MintGreen else Color.Transparent,
                        contentColor = if (isBuyFlow) DeepCharcoal else MutedGray
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("trade_buy_toggle")
                ) {
                    Text(viewModel.translate("deposit_usdt"), fontWeight = FontWeight.Bold)
                }
                Button(
                    onClick = { isBuyFlow = false },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (!isBuyFlow) WarmRed else Color.Transparent,
                        contentColor = if (!isBuyFlow) HighContrastWhite else MutedGray
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("trade_sell_toggle")
                ) {
                    Text(viewModel.translate("sell_usdt"), fontWeight = FontWeight.Bold)
                }
            }
        }

        // Ticker symbol picker list selection
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                coinSelectionList.forEach { coinSymbol ->
                    val isCoinChecked = selectedCoin == coinSymbol
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isCoinChecked) SoftMint else SurfaceCharcoal
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { selectedCoin = coinSymbol }
                            .border(
                                1.dp,
                                if (isCoinChecked) MintGreen else OutlinedGray,
                                RoundedCornerShape(8.dp)
                            )
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = coinSymbol,
                                color = if (isCoinChecked) MintGreen else HighContrastWhite,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Main input container card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCharcoal),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, OutlinedGray, RoundedCornerShape(16.dp))
                    .testTag("trade_input_card")
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = viewModel.translate("amount"), color = MutedGray, fontWeight = FontWeight.Bold)
                        val formattedBalance = String.format(Locale.US, "%,.2f USD", if (isBuyFlow) clientBalance else (if (selectedCoin == "BTC") userProfile?.btcBalance else userProfile?.ethBalance) ?: 0.0)
                        Text(
                            text = "${viewModel.translate("balance_lbl")} $formattedBalance",
                            color = MintGreen,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    OutlinedTextField(
                        value = enterAmountString,
                        onValueChange = { enterAmountString = it },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        textStyle = LocalTextStyle.current.copy(
                            color = HighContrastWhite,
                            fontWeight = FontWeight.Black,
                            fontSize = 24.sp
                        ),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = DeepCharcoal,
                            unfocusedContainerColor = DeepCharcoal,
                            focusedBorderColor = MintGreen,
                            unfocusedBorderColor = OutlinedGray
                        ),
                        shape = RoundedCornerShape(12.dp),
                        trailingIcon = {
                            Box(
                                modifier = Modifier
                                    .padding(end = 8.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(OutlinedGray)
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = if (isBuyFlow) "USDT" else selectedCoin,
                                    color = HighContrastWhite,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("trade_amount_input")
                    )

                    // Percentage selectors 0% - 100% cards matching SCREEN_3
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(0, 25, 50, 75, 100).forEach { pct ->
                            Card(
                                colors = CardDefaults.cardColors(containerColor = OutlinedGray),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable {
                                        if (isBuyFlow) {
                                            enterAmountString = String.format(Locale.US, "%.1f", (clientBalance * (pct / 100.0)))
                                        } else {
                                            val holding = if (selectedCoin == "BTC") userProfile?.btcBalance else userProfile?.ethBalance
                                            enterAmountString = String.format(Locale.US, "%.3f", ((holding ?: 0.0) * (pct / 100.0)))
                                        }
                                    }
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 8.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "$pct%",
                                        color = HighContrastWhite,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Direct payment selectors options
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = viewModel.translate("payment_method"),
                    fontWeight = FontWeight.Bold,
                    color = HighContrastWhite,
                    fontSize = 15.sp
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    PaymentWalletOptionCard(
                        title = "EVC Plus",
                        details = "0% KHIDMAD",
                        isSelected = selectedWalletOption == "EVC_PLUS",
                        onClick = { selectedWalletOption = "EVC_PLUS" },
                        modifier = Modifier.weight(1f)
                    )
                    PaymentWalletOptionCard(
                        title = "eDahab",
                        details = "0% KHIDMAD",
                        isSelected = selectedWalletOption == "EDAHAB",
                        onClick = { selectedWalletOption = "EDAHAB" },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Detailed Cost calculation summary
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCharcoal),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, OutlinedGray, RoundedCornerShape(12.dp))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = viewModel.translate("details_card"),
                        fontWeight = FontWeight.Bold,
                        color = HighContrastWhite,
                        fontSize = 14.sp
                    )

                    Divider(color = OutlinedGray, modifier = Modifier.padding(vertical = 4.dp))

                    SummaryRow(label = viewModel.translate("rate_lbl"), value = String.format(Locale.US, "$%,.2f USD", liveRate))
                    SummaryRow(
                        label = if (isBuyFlow) "Baqayda $selectedCoin" else "Baqayda USDT",
                        value = String.format(Locale.US, "%.6f %s", calculatedTargetCrypto, if (isBuyFlow) selectedCoin else "USDT")
                    )
                    SummaryRow(label = viewModel.translate("fee") + " (2%)", value = String.format(Locale.US, "%.2f USD", transactionFee))

                    Divider(color = OutlinedGray, modifier = Modifier.padding(vertical = 4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = viewModel.translate("total_cost"),
                            fontWeight = FontWeight.Bold,
                            color = HighContrastWhite,
                            fontSize = 16.sp
                        )
                        Text(
                            text = String.format(Locale.US, "%,.2f USD", grandTotalCost),
                            fontWeight = FontWeight.Black,
                            color = MintGreen,
                            fontSize = 18.sp
                        )
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF0F3D2A))
                            .padding(12.dp)
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Verified, contentDescription = "Verified status", tint = MintGreen, modifier = Modifier.size(16.dp))
                            Text(
                                text = "Khidmad la'aan ayaa si otomaatig ah loogu tabaqay beddelka EVC/eDahab.",
                                color = MintGreen,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 2
                            )
                        }
                    }
                }
            }
        }

        // Execute transactions trigger
        item {
            Button(
                onClick = {
                    if (parsedAmount <= 0) {
                        Toast.makeText(context, "Macaamil: Gali cadad canshuur ah.", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    if (isBuyFlow) {
                        viewModel.buyAsset(
                            symbol = selectedCoin,
                            cryptoAmount = calculatedTargetCrypto,
                            usdCost = parsedAmount,
                            onSuccess = {
                                Toast.makeText(context, "Hambalyo! $selectedCoin la iibsaday.", Toast.LENGTH_LONG).show()
                            },
                            onError = { err ->
                                Toast.makeText(context, "Cillad: $err", Toast.LENGTH_LONG).show()
                            }
                        )
                    } else {
                        viewModel.sellAsset(
                            symbol = selectedCoin,
                            cryptoAmount = parsedAmount, // Selling units
                            usdObtained = calculatedTargetCrypto,
                            onSuccess = {
                                Toast.makeText(context, "Hambalyo! $selectedCoin waad iibisay.", Toast.LENGTH_LONG).show()
                            },
                            onError = { err ->
                                Toast.makeText(context, "Cillad: $err", Toast.LENGTH_LONG).show()
                            }
                        )
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isBuyFlow) MintGreen else WarmRed,
                    contentColor = if (isBuyFlow) DeepCharcoal else HighContrastWhite
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("trade_submit_btn")
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = viewModel.translate("submit_button"),
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    Icon(imageVector = Icons.Default.ArrowForward, contentDescription = "Arrow")
                }
            }
        }
    }
}

@Composable
fun PaymentWalletOptionCard(
    title: String,
    details: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceCharcoal),
        shape = RoundedCornerShape(12.dp),
        modifier = modifier
            .clickable(onClick = onClick)
            .border(
                1.5.dp,
                if (isSelected) MintGreen else OutlinedGray,
                RoundedCornerShape(12.dp)
            )
    ) {
        Row(
            modifier = Modifier
                .padding(14.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (isSelected) MintGreen else OutlinedGray)
            ) {
                Icon(
                    imageVector = Icons.Default.Wallet,
                    contentDescription = title,
                    tint = if (isSelected) DeepCharcoal else HighContrastWhite,
                    modifier = Modifier.align(Alignment.Center)
                )
            }

            Column {
                Text(text = title, color = HighContrastWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(text = details, color = MintGreen, fontSize = 11.sp, fontWeight = FontWeight.Black)
            }
        }
    }
}

@Composable
fun SummaryRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, color = MutedGray, fontSize = 13.sp)
        Text(text = value, color = HighContrastWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}

// ----------------------------------------------------
// SCREEN 5/6: Wallet (Boorsada - Non-Admin)
// ----------------------------------------------------
@Composable
fun WalletScreen(viewModel: CryptoViewModel) {
    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
    val transactions by viewModel.userTransactions.collectAsStateWithLifecycle()
    val context = LocalContext.current

    // Deposit fields state tracker selectors
    var depositAmountString by remember { mutableStateOf("") }
    var referenceIdString by remember { mutableStateOf("") }
    var activeDepositSystem by remember { mutableStateOf("EVC_PLUS") } // EVC_PLUS or EDAHAB
    var screenshotUploadedPath by remember { mutableStateOf<String?>(null) } // Simulated local path or Uri String

    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            screenshotUploadedPath = uri.toString()
            Toast.makeText(context, "Rasiidka waa la doortay.", Toast.LENGTH_SHORT).show()
        }
    }

    // Estimated summation wealth calculation logic matching screenshots:
    // User total Estimated Wallet balance: $12,450.80
    // USDT Tether: 8,200 USDT
    // EVC: 2,150 USD
    // eDahab: 2,100 USD
    val usdtBal = userProfile?.usdtBalance ?: 0.0
    val evcBal = userProfile?.evcPlusBalance ?: 2150.0
    val edahabBal = userProfile?.eDahabBalance ?: 2100.0

    val estimatedWealth = usdtBal + evcBal + edahabBal

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(vertical = 12.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCharcoal),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, OutlinedGray, RoundedCornerShape(16.dp))
                    .testTag("wallet_balance_card")
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = viewModel.translate("estimated_balance_label"),
                        color = MutedGray,
                        fontWeight = FontWeight.Bold
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val displayWealth = if (userProfile != null) {
                            String.format(Locale.US, "$%,.2f USD", estimatedWealth)
                        } else {
                            "0.00 (Loading...)"
                        }
                        Text(
                            text = displayWealth,
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Black,
                            color = HighContrastWhite
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "↑ +2.4%",
                            color = MintGreen,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "• 3 Hantiyadood oola hayo (3 Assets)",
                            color = MutedGray,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        // Wallet Asset Holdings Card Breakdown list (Tether, EVC, eDahab)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "FAAHFAAHINTA HANTIDA",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = MutedGray
                )

                // Row 1: USDT
                WalletBreakdownRow(
                    name = "USDT",
                    subtitle = "Tether",
                    amount = String.format(Locale.US, "%,.2f", usdtBal),
                    value = String.format(Locale.US, "$%,.2f", usdtBal)
                )
                // Row 2: EVC Plus
                WalletBreakdownRow(
                    name = "EVC Plus",
                    subtitle = "Hormuud",
                    amount = String.format(Locale.US, "%,.2f", evcBal),
                    value = String.format(Locale.US, "$%,.2f", evcBal)
                )
                // Row 3: eDahab
                WalletBreakdownRow(
                    name = "eDahab",
                    subtitle = "Somtel",
                    amount = String.format(Locale.US, "%,.2f", edahabBal),
                    value = String.format(Locale.US, "$%,.2f", edahabBal)
                )
            }
        }

        // Fast Quick Dialer Deposits Interactive layout (*712* and *101*)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCharcoal),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.9.dp, OutlinedGray, RoundedCornerShape(16.dp))
                    .testTag("wallet_deposit_portal")
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = viewModel.translate("deposit_section"),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = HighContrastWhite
                    )

                    // Tab switchers inside deposit EVC vs eDahab
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(DeepCharcoal, RoundedCornerShape(8.dp))
                    ) {
                        Button(
                            onClick = { activeDepositSystem = "EVC_PLUS" },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (activeDepositSystem == "EVC_PLUS") SoftMint else Color.Transparent,
                                contentColor = if (activeDepositSystem == "EVC_PLUS") MintGreen else MutedGray
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Hormuud EVC", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Button(
                            onClick = { activeDepositSystem = "EDAHAB" },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (activeDepositSystem == "EDAHAB") SoftMint else Color.Transparent,
                                contentColor = if (activeDepositSystem == "EDAHAB") MintGreen else MutedGray
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Somtel eDahab", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }

                    val activeMerchantNumber = if (activeDepositSystem == "EVC_PLUS") "611444400" else "0629390022"
                    val promptCode = if (activeDepositSystem == "EVC_PLUS") "*712*$activeMerchantNumber*<Amount>#" else "*101*$activeMerchantNumber*<Amount>#"

                    Text(
                        text = "Ganacsade (Merchant): $activeMerchantNumber",
                        fontWeight = FontWeight.Black,
                        color = MintGreen,
                        fontSize = 14.sp
                    )

                    // Input target amount box
                    OutlinedTextField(
                        value = depositAmountString,
                        onValueChange = { depositAmountString = it },
                        label = { Text(viewModel.translate("enter_amount"), color = MutedGray) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = HighContrastWhite,
                            focusedBorderColor = MintGreen,
                            unfocusedBorderColor = OutlinedGray
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Input Reference ID check
                    OutlinedTextField(
                        value = referenceIdString,
                        onValueChange = { referenceIdString = it },
                        label = { Text(viewModel.translate("enter_ref"), color = MutedGray) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = HighContrastWhite,
                            focusedBorderColor = MintGreen,
                            unfocusedBorderColor = OutlinedGray
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Core dialer action trigger button
                    val compiledAmount = depositAmountString.ifEmpty { "0" }
                    val dialUssdCode = if (activeDepositSystem == "EVC_PLUS") "*712*611444400*$compiledAmount#" else "*101*0629390022*$compiledAmount#"

                    Button(
                        onClick = {
                            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(dialUssdCode)))
                            try {
                                context.startActivity(intent)
                                Toast.makeText(context, "Macaamil: USSD Dialer prefilled successfully.", Toast.LENGTH_SHORT).show()
                            } catch (e: Exception) {
                                Toast.makeText(context, "Prefilled USSD Dial code Code-ka: $dialUssdCode", Toast.LENGTH_LONG).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MintGreen, contentColor = DeepCharcoal),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = if (activeDepositSystem == "EVC_PLUS") "Ku bixi EVC Plus" else "Ku bixi eDahab",
                            fontWeight = FontWeight.Black
                        )
                    }

                    Text(
                        text = dialUssdCode,
                        textAlign = TextAlign.Center,
                        fontWeight = FontWeight.Bold,
                        color = MutedGray,
                        fontSize = 12.sp,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // Verified attachment widget screenshot uploads simulated framework
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCharcoal),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, OutlinedGray, RoundedCornerShape(16.dp))
                    .testTag("wallet_screenshot_portal")
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.CloudUpload, contentDescription = "Upload", tint = MintGreen)
                        Text(
                            text = "Hubi Dhigashadaada (Proof of Deposit)",
                            fontWeight = FontWeight.Bold,
                            color = HighContrastWhite,
                            fontSize = 14.sp
                        )
                    }

                    Text(
                        text = viewModel.translate("help_text"),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MutedGray
                    )

                    // Real and simulated receipt options
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Button(
                            onClick = {
                                try {
                                    imagePickerLauncher.launch("image/*")
                                } catch (e: Exception) {
                                    Toast.makeText(context, "Macaamil: Doorashada sawirka ma suurtagalin.", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MintGreen, contentColor = DeepCharcoal),
                            modifier = Modifier.weight(1.2f)
                        ) {
                            Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(viewModel.translate("screenshot_btn"), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                screenshotUploadedPath = "EVC_PLUS_Receipt_${referenceIdString.ifEmpty { "99XJ-11" }}.png"
                                Toast.makeText(context, "Rasiidka tijaabada ah waa la sameeyay.", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = OutlinedGray, contentColor = HighContrastWhite),
                            modifier = Modifier.weight(0.9f)
                        ) {
                            Text("Tijaabo", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        if (screenshotUploadedPath != null) {
                            Button(
                                onClick = {
                                    screenshotUploadedPath = null
                                    Toast.makeText(context, "Waa la dhowray.", Toast.LENGTH_SHORT).show()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0x33F6465D), contentColor = WarmRed),
                                modifier = Modifier.weight(0.7f)
                            ) {
                                Text("Tirtir", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    if (screenshotUploadedPath != null) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(60.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF0F3D2A))
                                .border(1.dp, MintGreen, RoundedCornerShape(8.dp))
                                .padding(12.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Image, contentDescription = "Uploaded path", tint = MintGreen)
                                Text(
                                    text = screenshotUploadedPath!!,
                                    color = HighContrastWhite,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }

                    // Bottom execute submit transaction trigger to wait for admin approval
                    Button(
                        onClick = {
                            val amountVal = depositAmountString.toDoubleOrNull() ?: 0.0
                            if (amountVal <= 0) {
                                Toast.makeText(context, "Macaamil: Gali cadad lacag kugu habboon.", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            val refId = referenceIdString.ifEmpty { "TX-" + UUID.randomUUID().toString().take(6).uppercase() }

                            viewModel.submitDeposit(
                                amount = amountVal,
                                paymentMethod = if (activeDepositSystem == "EVC_PLUS") "EVC Plus" else "eDahab",
                                referenceId = refId,
                                screenshotPath = screenshotUploadedPath
                            )
                            Toast.makeText(context, "Codsiga dhigashada waa la gudbiyay. Sugaya ansixinta admin-ka.", Toast.LENGTH_LONG).show()

                            // Reset state
                            depositAmountString = ""
                            referenceIdString = ""
                            screenshotUploadedPath = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MintGreen, contentColor = DeepCharcoal),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Dhigasho Geli", fontWeight = FontWeight.Black)
                    }

                    // WhatsApp Instant Intent notification dispatch button
                    Button(
                        onClick = {
                            val amountVal = depositAmountString.ifEmpty { "100" }
                            val platformName = if (activeDepositSystem == "EVC_PLUS") "EVC Plus" else "eDahab"
                            val refId = referenceIdString.ifEmpty { "99XJ-11" }

                            val userEmailText = userProfile?.email ?: "Unknown user"
                            val reportMessage = "Sahal Crypto Service Request:\nUser: $userEmailText\nAmount: $$amountVal USD\nProvider: $platformName\nReference CODE: $refId\nStatus: SUGAYA ANSIXIN"
                            val encodedMessage = Uri.encode(reportMessage)
                            val waIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://api.whatsapp.com/send?phone=252611444400&text=$encodedMessage"))
                            try {
                                context.startActivity(waIntent)
                            } catch (e: Exception) {
                                Toast.makeText(context, "WhatsApp report prepared for admin +252611444400", Toast.LENGTH_LONG).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366), contentColor = DeepCharcoal),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(imageVector = Icons.Default.Send, contentDescription = "WhatsApp icon", tint = DeepCharcoal)
                            Text("Ogeysii WhatsApp", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Secondary historical client logs transactions listing
        item {
            Text(
                text = "DHAQDHAQAAQII U DAMBEEYAY (HISTORY)",
                fontSize = 12.sp,
                color = MutedGray,
                fontWeight = FontWeight.SemiBold
            )
        }

        if (transactions.isEmpty()) {
            item {
                EmptyStateCard("Macaamil: Ma jiraan dhaqdhaqaaqyo dambe.")
            }
        } else {
            items(transactions) { transaction ->
                TransactionCardRow(transaction, viewModel)
            }
        }
    }
}

@Composable
fun WalletBreakdownRow(name: String, subtitle: String, amount: String, value: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceCharcoal),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, OutlinedGray, RoundedCornerShape(12.dp))
    ) {
        Row(
            modifier = Modifier
                .padding(14.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(OutlinedGray)
                ) {
                    Text(
                        text = name.take(2).uppercase(),
                        color = MintGreen,
                        fontWeight = FontWeight.Black,
                        fontSize = 12.sp,
                        modifier = Modifier.align(Alignment.Center)
                    )
                }

                Column {
                    Text(text = name, color = HighContrastWhite, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(text = subtitle, color = MutedGray, fontSize = 12.sp)
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(text = amount, color = HighContrastWhite, fontWeight = FontWeight.Black, fontSize = 14.sp)
                Text(text = value, color = MutedGray, fontSize = 12.sp)
            }
        }
    }
}

// ----------------------------------------------------
// SCREEN 4: Admin Dashboard (Ansixinta)
// ----------------------------------------------------
@Composable
fun AdminApprovalsScreen(viewModel: CryptoViewModel) {
    val transactionList by viewModel.allTransactions.collectAsStateWithLifecycle()
    val context = LocalContext.current

    // Admin pending deposits listings
    val pendingItems = remember(transactionList) {
        transactionList.filter { it.status == "SUGAYA_ANSIXIN" }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        // High visibility administrative safety banner
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F3D2A)),
                shape = RoundedCornerShape(0.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("admin_restriction_banner")
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = viewModel.translate("admin_banner"),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        color = MintGreen,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        // Dashboard admin statistics counters
        item {
            Column(
                modifier = Modifier.padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    AdminMetricCard(
                        title = "Cadadka Sugaya",
                        value = "$42,910.00",
                        pct = "↑ 12.4% marka la barbar dhigo shalay",
                        modifier = Modifier.weight(1.3f)
                    )
                    AdminMetricCard(
                        title = "Codsiyada Sugaya",
                        value = "${pendingItems.size} Macaamil",
                        pct = "Caddaynta dhabta ah",
                        modifier = Modifier.weight(1f)
                    )
                }
                AdminMetricCard(
                    title = "Maalinle la ansixiyay",
                    value = "148 Macaamil",
                    pct = "Habka tooska ah ee xog bixinta",
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // Pending applications table header
        item {
            Text(
                text = "PENDING DEPOSITS VERIFICATION FEED",
                color = MutedGray,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
        }

        if (pendingItems.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                ) {
                    EmptyStateCard("Ehem! Macaamil kasta oo cusub hadda waa la xaqiijiyay dhamaantood.")
                }
            }
        } else {
            items(pendingItems) { transaction ->
                AdminVerifyItemCard(transaction = transaction, viewModel = viewModel)
            }
        }
    }
}

@Composable
fun AdminMetricCard(title: String, value: String, pct: String, modifier: Modifier = Modifier) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceCharcoal),
        shape = RoundedCornerShape(12.dp),
        modifier = modifier.border(1.dp, OutlinedGray, RoundedCornerShape(12.dp))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(text = title, color = MutedGray, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text(text = value, color = HighContrastWhite, fontWeight = FontWeight.Black, fontSize = 20.sp)
            Text(text = pct, color = MintGreen, fontSize = 11.sp, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
fun AdminVerifyItemCard(transaction: Transaction, viewModel: CryptoViewModel) {
    val context = LocalContext.current
    val dateString = remember(transaction.timestamp) {
        SimpleDateFormat("MMM dd, hh:mm a", Locale.getDefault()).format(Date(transaction.timestamp))
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceCharcoal),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .border(1.dp, OutlinedGray, RoundedCornerShape(16.dp))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Profile details header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(
                        text = "MACAAMILKA (USER)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MutedGray
                    )
                    Text(
                        text = transaction.userEmail.substringBefore("@"),
                        color = HighContrastWhite,
                        fontWeight = FontWeight.Black,
                        fontSize = 15.sp
                    )
                    Text(
                        text = transaction.userEmail,
                        fontSize = 12.sp,
                        color = MutedGray
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFF3F3514))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text("PENDING", color = LightYellow, fontWeight = FontWeight.Black, fontSize = 11.sp)
                }
            }

            // Expected amount details
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("CADADKA (AMOUNT)", color = MutedGray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text(
                        text = String.format(Locale.US, "$%,.2f", transaction.amount),
                        color = MintGreen,
                        fontWeight = FontWeight.Black,
                        fontSize = 18.sp
                    )
                }
                Column(modifier = Modifier.weight(1.3f)) {
                    Text("PAYMENT & REFERENCE", color = MutedGray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text(
                        text = "${transaction.paymentMethod} • ID: ${transaction.referenceId}",
                        color = HighContrastWhite,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp
                    )
                }
            }

            // Simulated file receipt/Screenshot representation widget inside device mock
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(DeepCharcoal)
                    .border(1.dp, OutlinedGray, RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(MintGreen))
                        Text("SMS Screenshot receipt file layout verified.", color = MintGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Divider(color = OutlinedGray, modifier = Modifier.padding(vertical = 4.dp))

                    Text(
                        text = "Sender Name: Ahmed Warsame\nAmount Received: $${transaction.amount}\nReference Number: ${transaction.referenceId}\nTerminal: Hormuud Telecom EVC\nDate: $dateString",
                        color = MutedGray,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        lineHeight = 15.sp,
                        maxLines = 5
                    )
                }
            }

            // Action Approval / Reject button Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Button(
                    onClick = {
                        viewModel.adminProcessTransaction(id = transaction.id, approve = false)
                        Toast.makeText(context, "Macaamilka codisgiisa waa la diiday.", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0x22F6465D), contentColor = WarmRed),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("admin_deny_btn")
                ) {
                    Text("Diid (Reject)", fontWeight = FontWeight.Bold)
                }

                Button(
                    onClick = {
                        viewModel.adminProcessTransaction(id = transaction.id, approve = true)
                        Toast.makeText(context, "Macaamilka codisgiisa si guul leh ayaa loo ansixiyay!", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MintGreen, contentColor = DeepCharcoal),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1.3f)
                        .testTag("admin_approve_btn")
                ) {
                    Text("Ansixi (Approve)", fontWeight = FontWeight.Black)
                }
            }
        }
    }
}

// ----------------------------------------------------
// SCREEN 7: Settings/Configuration (Habaynta)
// ----------------------------------------------------
@Composable
fun SettingsScreen(viewModel: CryptoViewModel, onClose: () -> Unit) {
    val activeLanguage by viewModel.currentLanguage.collectAsStateWithLifecycle()
    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
    val activeEmail by viewModel.currentUserEmail.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var editNameString by remember { mutableStateOf("") }
    var editEmailString by remember { mutableStateOf("") }
    var displayEditProfileDialog by remember { mutableStateOf(false) }

    var localNotificationsEnabled by remember { mutableStateOf(true) }

    LaunchedEffect(userProfile) {
        userProfile?.let {
            editNameString = it.name
            editEmailString = it.email
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(vertical = 12.dp)
    ) {
        // Simple back action button row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onClose) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = HighContrastWhite)
                }
                Text(
                    text = viewModel.translate("settings"),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = HighContrastWhite
                )
                Spacer(modifier = Modifier.width(48.dp))
            }
        }

        // Active profile summary component card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCharcoal),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, OutlinedGray, RoundedCornerShape(16.dp))
                    .testTag("settings_profile_card")
            ) {
                Row(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(MintGreen)
                        ) {
                            Text(
                                text = (userProfile?.name ?: "S").take(1).uppercase(),
                                color = DeepCharcoal,
                                fontWeight = FontWeight.Black,
                                fontSize = 18.sp,
                                modifier = Modifier.align(Alignment.Center)
                            )
                        }

                        Column {
                            Text(
                                text = userProfile?.name ?: "Sahal User",
                                color = HighContrastWhite,
                                fontWeight = FontWeight.Black,
                                fontSize = 16.sp
                            )
                            Text(
                                text = activeEmail,
                                color = MutedGray,
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    // Clickable profile editor (Beddel) matching screenshots
                    Button(
                        onClick = { displayEditProfileDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = MintGreen, contentColor = DeepCharcoal),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Text("Beddel", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }

        // Dynamic Language Dropdown Switcher matching style
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCharcoal),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, OutlinedGray, RoundedCornerShape(16.dp))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = viewModel.translate("language_lbl"),
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = HighContrastWhite
                    )

                    // Compact horizontal inline toggle matching screenshot styling
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(Language.SOMALI, Language.ARABIC, Language.ENGLISH).forEach { lang ->
                            val isChecked = activeLanguage == lang
                            val label = when (lang) {
                                Language.SOMALI -> "Somali"
                                Language.ARABIC -> "العربية"
                                Language.ENGLISH -> "English"
                            }

                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isChecked) MintGreen else OutlinedGray
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { viewModel.setLanguage(lang) }
                                    .border(
                                        1.dp,
                                        if (isChecked) MintGreen else Color.Transparent,
                                        RoundedCornerShape(8.dp)
                                    )
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 10.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = label,
                                        color = if (isChecked) DeepCharcoal else HighContrastWhite,
                                        fontWeight = FontWeight.Black,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Standard Setting layout rows (Security, Notifications, Dark mode, Legal About)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCharcoal),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, OutlinedGray, RoundedCornerShape(16.dp))
            ) {
                Column(
                    modifier = Modifier.padding(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    SettingOptionRow(
                        title = viewModel.translate("security_title"),
                        icon = Icons.Outlined.Security,
                        rightElement = {
                            Icon(Icons.Default.ChevronRight, contentDescription = "Go", tint = MutedGray)
                        }
                    )

                    SettingOptionRow(
                        title = viewModel.translate("notification_lbl"),
                        icon = Icons.Outlined.Notifications,
                        rightElement = {
                            Switch(
                                checked = localNotificationsEnabled,
                                onCheckedChange = { localNotificationsEnabled = it },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = DeepCharcoal,
                                    checkedTrackColor = MintGreen,
                                    uncheckedThumbColor = MutedGray,
                                    uncheckedTrackColor = OutlinedGray
                                )
                            )
                        }
                    )

                    SettingOptionRow(
                        title = viewModel.translate("dark_mode_lbl"),
                        icon = Icons.Outlined.DarkMode,
                        rightElement = {
                            Switch(
                                checked = true,
                                onCheckedChange = { /* Forced to dark theme */ },
                                enabled = false,
                                colors = SwitchDefaults.colors(
                                    disabledCheckedThumbColor = DeepCharcoal,
                                    disabledCheckedTrackColor = MintGreen
                                )
                            )
                        }
                    )

                    SettingOptionRow(
                        title = viewModel.translate("about_lbl"),
                        icon = Icons.Outlined.Info,
                        onClick = {
                            try {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://sahalcrypt.com"))
                                context.startActivity(intent)
                            } catch (e: Exception) {
                                Toast.makeText(context, "Browser-ka ma furmi karo.", Toast.LENGTH_SHORT).show()
                            }
                        },
                        rightElement = {
                            Icon(Icons.Default.ChevronRight, contentDescription = "Go", tint = MutedGray)
                        }
                    )

                    SettingOptionRow(
                        title = viewModel.translate("website_lbl"),
                        icon = Icons.Outlined.Language,
                        onClick = {
                            try {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://sahalcrypt.com"))
                                context.startActivity(intent)
                            } catch (e: Exception) {
                                Toast.makeText(context, "Browser-ka ma furmi karo.", Toast.LENGTH_SHORT).show()
                            }
                        },
                        rightElement = {
                            Icon(Icons.Default.ChevronRight, contentDescription = "Go", tint = MutedGray)
                        }
                    )
                }
            }
        }

        // Absolute robust system Log Out button clears caches safely
        item {
            Button(
                onClick = {
                    // Safe cleanup reset to default profile representation
                    viewModel.setCurrentUser("user@sahalcrypto.so")
                    Toast.makeText(context, "Session reset successfully.", Toast.LENGTH_SHORT).show()
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0x22F6465D), contentColor = WarmRed),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .border(1.dp, WarmRed, RoundedCornerShape(12.dp))
                    .testTag("settings_logout_btn")
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.ExitToApp, contentDescription = "Log Out")
                    Text(
                        text = viewModel.translate("logout_btn"),
                        fontWeight = FontWeight.Black,
                        fontSize = 15.sp
                    )
                }
            }
        }
    }

    // Modal Profile/Email changer dialog to allow toggling standard user or hardcoded Admin!
    if (displayEditProfileDialog) {
        Dialog(onDismissRequest = { displayEditProfileDialog = false }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceCharcoal),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.5.dp, MintGreen, RoundedCornerShape(16.dp))
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = viewModel.translate("sec_profile"),
                        color = HighContrastWhite,
                        fontWeight = FontWeight.Black,
                        fontSize = 18.sp
                    )

                    OutlinedTextField(
                        value = editNameString,
                        onValueChange = { editNameString = it },
                        label = { Text("Name", color = MutedGray) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = HighContrastWhite,
                            focusedBorderColor = MintGreen,
                            unfocusedBorderColor = OutlinedGray
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = editEmailString,
                        onValueChange = { editEmailString = it },
                        label = { Text(viewModel.translate("enter_email"), color = MutedGray) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = HighContrastWhite,
                            focusedBorderColor = MintGreen,
                            unfocusedBorderColor = OutlinedGray
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Tip helper showing the credentials email that unlocks admin mode
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF3F3514))
                            .padding(10.dp)
                    ) {
                        Text(
                            text = "Admin check (Email-ka): ma611444400@gmail.com",
                            color = LightYellow,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { displayEditProfileDialog = false },
                            colors = ButtonDefaults.buttonColors(containerColor = OutlinedGray, contentColor = HighContrastWhite),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Dhaaf (Cancel)", fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                if (editEmailString.trim().isNotEmpty()) {
                                    // Save changes trigger
                                    viewModel.setCurrentUser(editEmailString.trim())
                                    displayEditProfileDialog = false
                                    Toast.makeText(context, "Macaamilka profile waa la keydiyay!", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MintGreen, contentColor = DeepCharcoal),
                            modifier = Modifier.weight(1.3f)
                        ) {
                            Text(viewModel.translate("save_btn"), fontWeight = FontWeight.Black)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingOptionRow(
    title: String,
    icon: ImageVector,
    onClick: (() -> Unit)? = null,
    rightElement: @Composable () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(OutlinedGray)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = MintGreen,
                    modifier = Modifier
                        .size(20.dp)
                        .align(Alignment.Center)
                )
            }
            Text(text = title, color = HighContrastWhite, fontWeight = FontWeight.Medium, fontSize = 14.sp)
        }

        rightElement()
    }
}

// ----------------------------------------------------
// UI Supporting components: Placeholder empty listing states
// ----------------------------------------------------
@Composable
fun EmptyStateCard(message: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceCharcoal),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, OutlinedGray, RoundedCornerShape(12.dp))
    ) {
        Column(
            modifier = Modifier
                .padding(24.dp)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(Icons.Default.Inbox, contentDescription = "Empty", tint = MutedGray, modifier = Modifier.size(32.dp))
            Text(
                text = message,
                color = MutedGray,
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
                fontWeight = FontWeight.Medium,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

// ----------------------------------------------------
// LIGHTWEIGHT INITIALIZATION SCREEN (SPLASH SCREEN)
// ----------------------------------------------------
@Composable
fun SplashLoadingScreen() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(DeepCharcoal),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // Elegant placeholder icon representation (No heavy custom drawables)
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color(0x1A00C087))
                    .border(2.dp, MintGreen, RoundedCornerShape(24.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.CurrencyExchange,
                    contentDescription = "Sahal Crypto Logo",
                    tint = MintGreen,
                    modifier = Modifier.size(40.dp)
                )
            }

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = "Sahal Crypto",
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Black,
                    color = HighContrastWhite,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "Ammaan, Fudayd & Degganaan",
                    fontSize = 12.sp,
                    color = MutedGray,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            CircularProgressIndicator(
                color = MintGreen,
                strokeWidth = 3.dp,
                modifier = Modifier.size(36.dp)
            )
        }
    }
}
