package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = MintGreen,
    onPrimary = DeepCharcoal,
    secondary = MintGreen,
    onSecondary = DeepCharcoal,
    tertiary = LightYellow,
    background = DeepCharcoal,
    onBackground = HighContrastWhite,
    surface = SurfaceCharcoal,
    onSurface = HighContrastWhite,
    surfaceVariant = AlertCardGray,
    onSurfaceVariant = MutedGray,
    outline = OutlinedGray,
    error = WarmRed
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Force premium dark mode for Fintech Minimalist styling
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
