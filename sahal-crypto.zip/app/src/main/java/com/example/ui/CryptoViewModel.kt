package com.example.ui

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.CryptoAsset
import com.example.data.model.Transaction
import com.example.data.model.UserProfile
import com.example.data.repository.CryptoRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class Language {
    SOMALI, ARABIC, ENGLISH
}

class CryptoViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = CryptoRepository(application)

    // Current app locale state
    private val _currentLanguage = MutableStateFlow(Language.SOMALI)
    val currentLanguage: StateFlow<Language> = _currentLanguage.asStateFlow()

    // Current active user's email
    private val _currentUserEmail = MutableStateFlow("user@sahalcrypto.so")
    val currentUserEmail: StateFlow<String> = _currentUserEmail.asStateFlow()

    // Dynamic reactive stream of the logged-in user profile details
    val userProfile: StateFlow<UserProfile?> = _currentUserEmail
        .flatMapLatest { email -> repository.getUserFlow(email) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // All transaction history for the admin
    val allTransactions: StateFlow<List<Transaction>> = repository.allTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Transactions filtered for specific user
    val userTransactions: StateFlow<List<Transaction>> = _currentUserEmail
        .flatMapLatest { email -> repository.getTransactionsByUserFlow(email) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Live asset rates stream from cache/API
    val cryptoAssets: StateFlow<List<CryptoAsset>> = repository.allAssets
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Filtered assets by search
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // Active Category Filter for Markets (All, DeFi, Layer 1, Stablecoins)
    private val _selectedCategory = MutableStateFlow("DHAMMAAN")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    val filteredCryptoAssets: StateFlow<List<CryptoAsset>> = combine(
        cryptoAssets,
        _searchQuery,
        _selectedCategory
    ) { assets, query, category ->
        var list = assets
        if (category != "DHAMMAAN") {
            list = list.filter { it.category == category }
        }
        if (query.isNotEmpty()) {
            list = list.filter {
                it.name.contains(query, ignoreCase = true) ||
                        it.symbol.contains(query, ignoreCase = true)
            }
        }
        list
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // API loading & error states
    private val _isRefreshing = MutableStateFlow(false)
    val isRefreshing: StateFlow<Boolean> = _isRefreshing.asStateFlow()

    private val _apiError = MutableStateFlow<String?>(null)
    val apiError: StateFlow<String?> = _apiError.asStateFlow()

    init {
        // Initial setup
        viewModelScope.launch(Dispatchers.IO) {
            repository.seedDefaultAssets()
            repository.getOrCreateProfile("user@sahalcrypto.so", "Sahal User")
            repository.getOrCreateProfile("ma611444400@gmail.com", "Maamule (Admin)")
        }

        // Live API Polling Loop (every 60 seconds) - DISABLED for Bare-Bones stable startup
        viewModelScope.launch(Dispatchers.IO) {
            // Wait for DB to seed default values first
            delay(1500)
            while (true) {
                try {
                    // Back-end polling disabled on start; data-fetching must be user-triggered
                    // repository.fetchLiveCryptoFeed()
                    _apiError.value = null
                } catch (e: Exception) {
                    Log.e("CryptoViewModel", "Background polling error: ${e.message}")
                }
                delay(60000) // 60 seconds interval polling
            }
        }
    }

    fun refreshData() {
        viewModelScope.launch {
            _isRefreshing.value = true
            _apiError.value = null
            try {
                val result = kotlinx.coroutines.withContext(Dispatchers.IO) {
                    try {
                        repository.fetchLiveCryptoFeed()
                        true
                    } catch (e: Exception) {
                        false
                    }
                }
                if (!result) {
                    _apiError.value = "Khadka API wuu kala go'ay. Fadlan dib u tijaabi. / Network connection failed. Please retry."
                }
            } catch (e: Exception) {
                _apiError.value = e.localizedMessage ?: "Cilad farsamo ayaa dhacday."
            } finally {
                _isRefreshing.value = false
            }
        }
    }

    fun setLanguage(language: Language) {
        _currentLanguage.value = language
    }

    fun setCurrentUser(email: String) {
        if (email.trim().isNotEmpty()) {
            _currentUserEmail.value = email.trim()
            viewModelScope.launch(Dispatchers.IO) {
                // Ensure profile is initialized in DB
                repository.getOrCreateProfile(email.trim(), email.trim().substringBefore("@"))
            }
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSelectedCategory(category: String) {
        _selectedCategory.value = category
    }

    // Submit deposit (Client-side trigger enters Suggested Pending list in Room database)
    fun submitDeposit(amount: Double, paymentMethod: String, referenceId: String, screenshotPath: String?) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.submitDeposit(
                email = _currentUserEmail.value,
                amount = amount,
                paymentMethod = paymentMethod,
                referenceId = referenceId,
                screenshotPath = screenshotPath
            )
        }
    }

    // Submit withdrawal (Immediately locks user balances into Suggested Pending list)
    fun submitWithdrawal(amount: Double, paymentMethod: String, onSuccess: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val success = repository.submitWithdrawal(
                email = _currentUserEmail.value,
                amount = amount,
                paymentMethod = paymentMethod
            )
            launch(Dispatchers.Main) {
                if (success) onSuccess() else onError("Haraagaagu kuguma filna. / Insufficient balance.")
            }
        }
    }

    // Buy orders (Calculated client/offline state instantly matches available USDT)
    fun buyAsset(symbol: String, cryptoAmount: Double, usdCost: Double, onSuccess: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val success = repository.buyAsset(
                email = _currentUserEmail.value,
                symbol = symbol,
                cryptoAmount = cryptoAmount,
                usdCost = usdCost
            )
            launch(Dispatchers.Main) {
                if (success) onSuccess() else onError("USDT balance is insufficient.")
            }
        }
    }

    // Sell orders
    fun sellAsset(symbol: String, cryptoAmount: Double, usdObtained: Double, onSuccess: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val success = repository.sellAsset(
                email = _currentUserEmail.value,
                symbol = symbol,
                cryptoAmount = cryptoAmount,
                usdObtained = usdObtained
            )
            launch(Dispatchers.Main) {
                if (success) onSuccess() else onError("Insufficient $symbol holdings to trade.")
            }
        }
    }

    // Admin commands: Approve / deny transactions securely
    fun adminProcessTransaction(id: Long, approve: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.adminProcessTransaction(id, approve)
        }
    }

    // High fidelity multi-language resolver API (Somali / Arabic / English)
    fun translate(key: String): String {
        val s = translations[_currentLanguage.value]?.get(key)
        if (s != null) return s

        // fallback to English translation
        return translations[Language.ENGLISH]?.get(key) ?: key
    }

    companion object {
        private val translations = mapOf(
            Language.SOMALI to mapOf(
                "app_title" to "Sahal Crypto",
                "dashboard" to "Dashboard",
                "wallet" to "Boorsada",
                "markets" to "Suuqa",
                "trade" to "Ganacsiga",
                "settings" to "Habaynta",
                "admin_tab" to "Ansixinta",
                "total_balance" to "Isku-darka Haraaga",
                "deposit_button" to "Iibso Crypto",
                "withdraw_button" to "Iibi / Lacag bixi",
                "p2p_button" to "P2P-ka Gudaha",
                "scan_button" to "Skaan garee & Bixi",
                "recent_activity" to "Dhaqdhaqaaqii ugu dambeeyay",
                "see_all" to "Arag Dhammaan",
                "top_gainers" to "Kuwa ugu faa'iidada badan",
                "assets_top" to "Hantida ugu kulul",
                "market_header" to "Guudmarka Suuqa",
                "search_asset" to "Raadi hantida...",
                "deposit_usdt" to "Iibso USDT",
                "sell_usdt" to "Iibi USDT",
                "payment_method" to "Habka Lacag-bixinta",
                "fee" to "Khidmada",
                "see_details" to "Faahfaahinta",
                "submit_button" to "Eeg Ganacsiga",
                "deposit_section" to "Dhigasho Degdeg Ah",
                "screenshot_btn" to "Soo geli Sawirka",
                "whatsapp_btn" to "Ogeysii WhatsApp",
                "admin_required" to "SUGAYA ANSIXIN",
                "approved" to "LA ANSIXIYAY",
                "declined" to "LA DIIDAY",
                "logout_btn" to "Ka Bax",
                "market_update_text" to "Xogta waxay is cusboonaysiisaa 60-kii ilbidhiqsi kasta",
                "all" to "Dhammaan",
                "defi" to "DeFi",
                "layer1" to "Layer 1",
                "stablecoins" to "Stablecoins",
                "amount" to "Cadadka",
                "balance_lbl" to "Haraaga",
                "details_card" to "Faahfaahinta",
                "rate_lbl" to "Sicirka",
                "total_cost" to "Warta Guud",
                "withdraw_req" to "Codsiga Lacag bixin",
                "security_title" to "Amniga & Aqoonsiga",
                "language_lbl" to "Luqadda",
                "notification_lbl" to "Ogeysiisyada",
                "dark_mode_lbl" to "Habka Madow",
                "about_lbl" to "Ku saabsan Sahal",
                "website_lbl" to "Websaydhka Rasmiga (sahalcrypt.com)",
                "admin_banner" to "GALMADA MAAMULKA OO XADDIDAN: MA611444400@GMAIL.COM",
                "pending_req" to "Sugayaashii Cadadka",
                "approve_btn" to "Ansixi",
                "reject_btn" to "Diid",
                "enter_amount" to "Gali Cadadka ($)",
                "enter_ref" to "Gali Code-ka Reference ID (tusaale, 99XJ-11)",
                "screenshot_empty" to "Sawirka galka fariinta",
                "dial_instruction" to "Guji batoonka si aad u wacdo code-ka USSD:",
                "sec_profile" to "Maamul Profile-ka",
                "help_text" to "Hubi dhigashadaada adoo soo galinaya sawirka (screenshot) farriinta SMS-ka ama rasiidhka si loo dardargeliyo ansixinta.",
                "change_user_btn" to "Beddel Profile",
                "enter_email" to "Gali Email-ka",
                "save_btn" to "Keydi"
            ),
            Language.ARABIC to mapOf(
                "app_title" to "ساهل كريبتو",
                "dashboard" to "لوحة التحكم",
                "wallet" to "المحفظة",
                "markets" to "الأسواق",
                "trade" to "التداول",
                "settings" to "الإعدادات",
                "admin_tab" to "الموافقات",
                "total_balance" to "إجمالي الرصيد",
                "deposit_button" to "شراء كريبتو",
                "withdraw_button" to "بيع / سحب الرصيد",
                "p2p_button" to "تداول محلي P2P",
                "scan_button" to "امسح وادفع",
                "recent_activity" to "النشاط الأخير",
                "see_all" to "عرض الكل",
                "top_gainers" to "العملات الأكثر ربحاً",
                "assets_top" to "الأصول الشائعة",
                "market_header" to "نظرة عامة على السوق",
                "search_asset" to "البحث عن الأصول...",
                "deposit_usdt" to "شراء USDT",
                "sell_usdt" to "بيع USDT",
                "payment_method" to "طريقة الدفع",
                "fee" to "الرسوم",
                "see_details" to "التفاصيل",
                "submit_button" to "تنفيذ التداول",
                "deposit_section" to "إيداع سريع",
                "screenshot_btn" to "تحميل لقطة الشاشة",
                "whatsapp_btn" to "إشعار عبر واتساب",
                "admin_required" to "قيد الانتظار",
                "approved" to "تمت الموافقة",
                "declined" to "مرفوض",
                "logout_btn" to "تسجيل الخروج",
                "market_update_text" to "يتم تحديث البيانات تلقائياً كل 60 ثانية",
                "all" to "الكل",
                "defi" to "DeFi",
                "layer1" to "Layer 1",
                "stablecoins" to "Stablecoins",
                "amount" to "المبلغ",
                "balance_lbl" to "الرصيد الحالي",
                "details_card" to "التفاصيل والرسوم",
                "rate_lbl" to "السعر الحالي",
                "total_cost" to "الإجمالي الكلي",
                "withdraw_req" to "طلب سحب رصيد",
                "security_title" to "الأمان والتحقق",
                "language_lbl" to "اللغة المحددة",
                "notification_lbl" to "الإشعارات",
                "dark_mode_lbl" to "الوضع الليلي",
                "about_lbl" to "حول ساهل كريبتو",
                "website_lbl" to "الموقع الرسمي (sahalcrypt.com)",
                "admin_banner" to "إدارة تحكم المشرفين فقط: MA611444400@GMAIL.COM",
                "pending_req" to "طلبات في انتظار المراجعة",
                "approve_btn" to "موافقة",
                "reject_btn" to "رفض",
                "enter_amount" to "أدخل المبلغ بالدولار ($)",
                "enter_ref" to "أدخل رمز العملية (مثل، 99XJ-11)",
                "screenshot_empty" to "لم يتم إرفاق لقطة شاشة",
                "dial_instruction" to "انقر أدناه للاتصال برمز USSD لشبكة الدفع المباشر:",
                "sec_profile" to "إدارة الملف الشخصي",
                "help_text" to "يرجى إرفاق لقطة شاشة لرسالة تأكيد المعاملة المرسلة إليك لتسهيل عملية المراجعة والاعتماد السريع.",
                "change_user_btn" to "تبديل الحساب",
                "enter_email" to "أدخل البريد الإلكتروني المحقق",
                "save_btn" to "حفظ البيانات"
            ),
            Language.ENGLISH to mapOf(
                "app_title" to "Sahal Crypto",
                "dashboard" to "Dashboard",
                "wallet" to "Wallet",
                "markets" to "Markets",
                "trade" to "Trade",
                "settings" to "Settings",
                "admin_tab" to "Approvals",
                "total_balance" to "Total Balance",
                "deposit_button" to "Buy Crypto",
                "withdraw_button" to "Sell / Withdraw",
                "p2p_button" to "Local P2P",
                "scan_button" to "Scan & Pay",
                "recent_activity" to "Recent Activity",
                "see_all" to "See All",
                "top_gainers" to "Top Gainers",
                "assets_top" to "Hot Assets",
                "market_header" to "Market Overview",
                "search_asset" to "Search asset...",
                "deposit_usdt" to "Buy USDT",
                "sell_usdt" to "Sell USDT",
                "payment_method" to "Payment Method",
                "fee" to "Transaction Fee",
                "see_details" to "Details",
                "submit_button" to "Execute Trade",
                "deposit_section" to "Quick Deposit",
                "screenshot_btn" to "Upload Screenshot",
                "whatsapp_btn" to "WhatsApp Admin",
                "admin_required" to "PENDING APPROVAL",
                "approved" to "APPROVED",
                "declined" to "DECLINED",
                "logout_btn" to "Log Out",
                "market_update_text" to "Market rates update automatically every 60s",
                "all" to "All",
                "defi" to "DeFi",
                "layer1" to "Layer 1",
                "stablecoins" to "Stablecoins",
                "amount" to "Amount",
                "balance_lbl" to "Balance",
                "details_card" to "Transaction Summary",
                "rate_lbl" to "Market Price",
                "total_cost" to "Grand Total",
                "withdraw_req" to "Withdraw Request",
                "security_title" to "Security & Verified Profiles",
                "language_lbl" to "Selected Language",
                "notification_lbl" to "Notifications Alert",
                "dark_mode_lbl" to "Dark Visual Theme",
                "about_lbl" to "About Sahal Crypto",
                "website_lbl" to "Official Website (sahalcrypt.com)",
                "admin_banner" to "RESTRICTED ADMIN PANEL: MA611444400@GMAIL.COM",
                "pending_req" to "Pending Verification Queue",
                "approve_btn" to "Approve",
                "reject_btn" to "Reject",
                "enter_amount" to "Enter Amount ($)",
                "enter_ref" to "Enter Reference Number (e.g., 99XJ-11)",
                "screenshot_empty" to "No receipt screenshot uploaded",
                "dial_instruction" to "Click action button below to automatically dial USSD codes:",
                "sec_profile" to "Manage Profile Credentials",
                "help_text" to "Please attach a screenshot of your SMS transaction confirmation or transfer receipt so our administrators can verify and approve updates rapidly.",
                "change_user_btn" to "Change Account",
                "enter_email" to "Enter Registered Email",
                "save_btn" to "Save Profile"
            )
        )
    }
}
