package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val DeepCharcoal = Color(0xFF0B0E11)
val SurfaceCharcoal = Color(0xFF1C2127)
val AlertCardGray = Color(0xFF1E2329)
val MintGreen = Color(0xFF00C087)
val SoftMint = Color(0x3300C087)
val WarmRed = Color(0xFFF6465D)
val OutlinedGray = Color(0xFF2B3139)

val HighContrastWhite = Color(0xFFFFFFFF)
val MutedGray = Color(0xFF858D9E)
val LightYellow = Color(0xFFF0B90B)
